#include <iostream>
using namespace std;

int main()
{
    char tablero[3][3];
    int i, j;

    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            tablero[i][j] = ' ';
        }
    }

    char jugador = 'X';
    bool terminado = false;
    int movimientos = 0;

    while (!terminado)
    {
        cout << " " << tablero[0][0] << " | " << tablero[0][1] << " | " << tablero[0][2] << "\n";
        cout << "---|---|---\n";
        cout << " " << tablero[1][0] << " | " << tablero[1][1] << " | " << tablero[1][2] << "\n";
        cout << "---|---|---\n";
        cout << " " << tablero[2][0] << " | " << tablero[2][1] << " | " << tablero[2][2] << "\n";

        int pos;
        cout << "\nTurno de " << jugador << ". Ingresa posicion (1-9): ";
        cin >> pos;

        if (pos < 1 || pos > 9)
        {
            cout << "Movimiento invalido!\n";
            continue;
        }

        int fila = (pos - 1) / 3;
        int col = (pos - 1) % 3;

        if (tablero[fila][col] != ' ')
        {
            cout << "Casilla ocupada!\n";
            continue;
        }

        tablero[fila][col] = jugador;
        movimientos++;

        for (i = 0; i < 3; i++)
        {
            if (tablero[i][0] == jugador && tablero[i][1] == jugador && tablero[i][2] == jugador)
            {
                terminado = true;
            }
        }

        for (j = 0; j < 3; j++)
        {
            if (tablero[0][j] == jugador && tablero[1][j] == jugador && tablero[2][j] == jugador)
            {
                terminado = true;
            }
        }

        if (tablero[0][0] == jugador && tablero[1][1] == jugador && tablero[2][2] == jugador)
            terminado = true;
        if (tablero[0][2] == jugador && tablero[1][1] == jugador && tablero[2][0] == jugador)
            terminado = true;

        if (terminado)
        {
            cout << "\nJugador " << jugador << " gana!\n";
            break;
        }

        if (movimientos == 9)
        {
            cout << "\nEmpate!\n";
            break;
        }

        if (jugador == 'X')
            jugador = 'O';
        else
            jugador = 'X';
    }

    return 0;
}
